<?php
	$SERVER = 'mysql.cs.virginia.edu';
	$USERNAME = 'ak6eh';
	$PASSWORD = '5ag';
	$DATABASE = 'ak6eh';
?>
